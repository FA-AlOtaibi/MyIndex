
<div class="navbar">
  <div class="navbar-inner">
    <div class="left"><a href="#" class="back link"> <i class="icon icon-back"></i><span><h1>رجوع</span></a></div>
  <div class="right">
                        <a class="" href="javascript:window.location.reload(true)"> ♻︎تحديث♻︎ </a>
                     </div>
  </div>

<div class="pages">
  <div data-page="partners" class="page">
     <!-- Search Bar overlay-->
  	<form class="searchbar searchbar-init" data-search-in=".item-inner" data-search-list=".search-here">
								<div class="searchbar-input">
									<input placeholder="..بحث" type="search"><a class="searchbar-clear" href="#"></a>
								</div><a class="searchbar-cancel" href="#">الغاء</a>
							</form>
					<div class="page-content ">
							
		<div class="content-block" style="margin-top:0; margin-bottom:0;">
		<div class="content-block-inner">

		<!-- 	<h3>txt test</h3>
		<p> txt test txt test txt test txt test txt test txt test txt test txt test txt test txt test </p>
	<p>Please report to <a href="https://twitter.com/ipainstall" class="external">@ipainstall</a> if any of these sources or apps are not installing.</p>-->
		</div>
		</div>

							<!-- These are tweaked apps -->
						<div class="list-block search-here searchbar-found" style="margin-top: -1px;">
<ul>

    <!-- Inset content block -->
<br>
	      <!--  <div class="content-block-title">تطبيقات البلس</div>
	    
	    
	    
	        <!-- App -->
<li>
<div class="item-content">
<div class="item-media" style="margin-top: 18px;">
<img class="appImage" src="https://ipa-install.cf/images/CuteCutPro-icon.png" height="85px" style="margin-top: -10px; border-radius:22%;"></a>
</div>
<div class="item-inner">
<div class="item-title-row">
<div class="item-text1" style="   font-size:15px; font-weight: 700;">Cute Cut Pro</div>
<div class="a"><a style=" font-size: 70%; color: dimgrey; ">42.10MB</a><a style=" font-size: 83%; color: gray;"> | </a><a style=" font-size: 70%; color: dimgrey;">V10.20.1</a></div>
</div>
<div class="item-install">
<a class="button external button-round button-fill" href="itms-services://?action=download-manifest&amp;url=https%3A%2F%2Fapi.tweakboxapp.com%2Fdownload%2Fmsru3sdqVWaqotCiq4Tj3rWTiqVzpN1im8bbnbWglqq5o9iYYZnv4rlzm6uVptVhm8bb%2Ftitle%2FCute%2520Cut%2520Pro" target="_self" onclick="install(Cut Cut Pro);" style="background:#F0F1F6;color:dodgerblue;font-weight: bold;margin-top: -12px;float:right;">تثبيت</a>
</div>
</div>
</div>
</li>
	        <!-- App -->







<!-- App -->
<li>
<div class="item-content">
<div class="item-media" style="margin-top: 18px;">
<img class="appImage" src="https://itunes.apple.com/us/app/r-play-remote-play-for-the-ps4/id1222889057?mt=8" height="85px" style="margin-top: -10px; border-radius:22%;"></a>
</div>
<div class="item-inner">
<div class="item-title-row">
<div class="item-text1" style="   font-size:15px; font-weight: 700;">R-Play</div>
<div class="a"><a style=" font-size: 70%; color: dimgrey; ">42.10MB</a><a style=" font-size: 83%; color: gray;"> | </a><a style=" font-size: 70%; color: dimgrey;">V10.20.1</a></div>
</div>
<div class="item-install">
<a class="button external button-round button-fill" href="itms-services://?action=download-manifest&url=https://cydia-it.ml/r-plAY.plist" target="_self" onclick="install(R-Play);" style="background:#F0F1F6;color:dodgerblue;font-weight: bold;margin-top: -12px;float:right;">تثبيت</a>
</div>
</div>
</div>
</li>
	        <!-- App -->










	        <!-- App -->
<li>
<div class="item-content">
<div class="item-media" style="margin-top: 18px;">
<img class="appImage" src="http://images.tutuapp.com/picture/app_ios/cn/003/13/55/36/3135536.175x175-75.jpg?f=311107230ea2fb4a454f12c68fb0bf31" height="85px" style="margin-top: -10px; border-radius:22%;"></a>
</div>
<div class="item-inner">
<div class="item-title-row">
<div class="item-text1" style="   font-size:15px; font-weight: 700;">Bleach Online</div>
<div class="a"><a style=" font-size: 70%; color: dimgrey; ">460.94MB</a><a style=" font-size: 83%; color: gray;"> | </a><a style=" font-size: 70%; color: dimgrey;">V1.3.0</a></div>
</div>
<div class="item-install">
<a class="button external button-round button-fill" href="itms-services://?action=download-manifest&amp;url=https%3A%2F%2Fapi.tweakboxapp.com%2Fdownload%2Fmsru3o5fVZu0q9Rhqbvb3sReiaayY8ejosmp6LZfVmd4Y5dmYYuvnYdmVWx-mp9qaomxn7Vih5l5mZdpY4qz0IWRXGWupMc,%2Ftitle%2FBleach%2520Online" target="_self" onclick="install(Bleach Online);" style="background:#F0F1F6;color:dodgerblue;font-weight: bold;margin-top: -12px;float:right;">تثبيت</a>
</div>
</div>
</div>
</li>
	        <!-- App -->
	        



	        <!-- App -->
<li>
<div class="item-content">
<div class="item-media" style="margin-top: 18px;">
<img class="appImage" src="http://images.tutuapp.com/picture/app_ios/cn/003/06/69/99/3066999.175x175-75.jpg?f=311107230ea2fb4a454f12c68fb0bf31" height="85px" style="margin-top: -10px; border-radius:22%;"></a>
</div>
<div class="item-inner">
<div class="item-title-row">
<div class="item-text1" style="   font-size:15px; font-weight: 700;">Legacy of Discord-Multi Languages</div>
<div class="a"><a style=" font-size: 70%; color: dimgrey; ">95.16MB</a><a style=" font-size: 83%; color: gray;"> | </a><a style=" font-size: 70%; color: dimgrey;">V2.0.0</a></div>
</div>
<div class="item-install">
<a class="button external button-round button-fill" href="itms-services://?action=download-manifest&amp;url=https%3A%2F%2Fapi.tweakboxapp.com%2Fdownload%2Fmsru3o5fVZu0q9Rhqbvb3sReiaayY8ejosmp6LZfVmd4Y5ZpYYyznY1pVWx-mp5oa4uyn7Vih5l5mZdpZY7fpIlkiGWupMc,%2Ftitle%2FLegacy%2520of%2520Discord-Multi%2520Languages" target="_self" onclick="install(Legacy Discord);" style="background:#F0F1F6;color:dodgerblue;font-weight: bold;margin-top: -12px;float:right;">تثبيت</a>
</div>
</div>
</div>
</li>
	        <!-- App -->





	        <!-- App -->
<li>
<div class="item-content">
<div class="item-media" style="margin-top: 18px;">
<img class="appImage" src="http://images.tutuapp.com/picture/app_ios/cn/003/20/37/89/3203789.175x175-75.jpg?f=311107230ea2fb4a454f12c68fb0bf31" height="85px" style="margin-top: -10px; border-radius:22%;"></a>
</div>
<div class="item-inner">
<div class="item-title-row">
<div class="item-text1" style="   font-size:15px; font-weight: 700;">DBZ Dokkan Battle</div>
<div class="a"><a style=" font-size: 70%; color: dimgrey; ">339.55MB</a><a style=" font-size: 83%; color: gray;"> | </a><a style=" font-size: 70%; color: dimgrey;">V1.1.1</a></div>
</div>
<div class="item-install">
<a class="button external button-round button-fill" href="itms-services://?action=download-manifest&amp;url=https%3A%2F%2Fapi.tweakboxapp.com%2Fdownload%2Fmsru3o5fVZu0q9Rhqbvb3sReiaayY8ejosmp6LZfVmd4Y5hjYYmxnYxpVWx-mp5oloirn7Vih5l5mZdpZ43dpriTV2WupMc,%2Ftitle%2FDBZ%2520Dokkan%2520Battle" target="_self" onclick="install(DBZ Dokkan Battle);" style="background:#F0F1F6;color:dodgerblue;font-weight: bold;margin-top: -12px;float:right;">تثبيت</a>
</div>
</div>
</div>
</li>
	        <!-- App -->



	        <!-- App -->
<li>
<div class="item-content">
<div class="item-media" style="margin-top: 18px;">
<img class="appImage" src="https://server3.uaepro.me/files/21851/246929.png" height="85px" style="margin-top: -10px; border-radius:22%;"></a>
</div>
<div class="item-inner">
<div class="item-title-row">
<div class="item-text1" style="   font-size:15px; font-weight: 700;">Beinsport</div>
<div class="a"><a style=" font-size: 70%; color: dimgrey; ">2Mo</a><a style=" font-size: 83%; color: gray;"> | </a><a style=" font-size: 70%; color: dimgrey;">V1.0</a></div>
</div>
<div class="item-install">
<a class="button external button-round button-fill" href="itms-services://?action=download-manifest&amp;url=https://dzmohaipa.com/Snapchat/Beinsport.plist" target="_self" onclick="install(Beinsport);" style="background:#F0F1F6;color:dodgerblue;font-weight: bold;margin-top: -12px;float:right;">تثبيت</a>
</div>
</div>
</div>
</li>
	        <!-- App -->



	        <!-- App -->
<li>
<div class="item-content">
<div class="item-media" style="margin-top: 18px;">
<img class="appImage" src="https://img4.hostingpics.net/pics/603896Capture.png" height="85px" style="margin-top: -10px; border-radius:22%;"></a>
</div>
<div class="item-inner">
<div class="item-title-row">
<div class="item-text1" style="   font-size:15px; font-weight: 700;">CCgenAR</div>
<div class="a"><a style=" font-size: 70%; color: dimgrey; ">10.9Mo</a><a style=" font-size: 83%; color: gray;"> | </a><a style=" font-size: 70%; color: dimgrey;">V1.0</a></div>
</div>
<div class="item-install">
<a class="button external button-round button-fill" href="itms-services://?action=download-manifest&amp;url=https://dzmohaipa.com/Snapchat/CCgenAR.plist" target="_self" onclick="install(CCgenAR);" style="background:#F0F1F6;color:dodgerblue;font-weight: bold;margin-top: -12px;float:right;">تثبيت</a>
</div>
</div>
</div>
</li>
	        <!-- App -->



	        <!-- App -->
<li>
<div class="item-content">
<div class="item-media" style="margin-top: 18px;">
<img class="appImage" src="https://2.bp.blogspot.com/-39bxfv3Go8c/Wd6otBN5TsI/AAAAAAAAA64/cFwxazhjlMEoiA4JdM71FKcuALgJdwyMQCLcBGAs/s1600/te_le_chargement%2B%25282%2529.png" height="85px" style="margin-top: -10px; border-radius:22%;"></a>
</div>
<div class="item-inner">
<div class="item-title-row">
<div class="item-text1" style="   font-size:15px; font-weight: 700;">Dalila</div>
<div class="a"><a style=" font-size: 70%; color: dimgrey; ">4.6Mo</a><a style=" font-size: 83%; color: gray;"> | </a><a style=" font-size: 70%; color: dimgrey;">V3.0</a></div>
</div>
<div class="item-install">
<a class="button external button-round button-fill" href="itms-services://?action=download-manifest&amp;url=https://dzmohaipa.com/Snapchat/Dalila.plist" target="_self" onclick="install(Dalila);" style="background:#F0F1F6;color:dodgerblue;font-weight: bold;margin-top: -12px;float:right;">تثبيت</a>
</div>
</div>
</div>
</li>
	        <!-- App -->



	        <!-- App -->
<li>
<div class="item-content">
<div class="item-media" style="margin-top: 18px;">
<img class="appImage" src="https://4.bp.blogspot.com/-N8GxdXeQDHU/Wd7IAUcN9gI/AAAAAAAAA7g/bN08saLMxj45b6WacA7yKZgC3BrVDG_WwCLcBGAs/s1600/te_le_chargement.png" height="85px" style="margin-top: -10px; border-radius:22%;"></a>
</div>
<div class="item-inner">
<div class="item-title-row">
<div class="item-text1" style="   font-size:15px; font-weight: 700;">FootballChairman</div>
<div class="a"><a style=" font-size: 70%; color: dimgrey; ">19.9Mo</a><a style=" font-size: 83%; color: gray;"> | </a><a style=" font-size: 70%; color: dimgrey;">V1.3.1</a></div>
</div>
<div class="item-install">
<a class="button external button-round button-fill" href="itms-services://?action=download-manifest&amp;url=https://dzmohaipa.com/Snapchat/FootballChairman.plist" target="_self" onclick="install(FootballChairman);" style="background:#F0F1F6;color:dodgerblue;font-weight: bold;margin-top: -12px;float:right;">تثبيت</a>
</div>
</div>
</div>
</li>
	        <!-- App -->



	        <!-- App -->
<li>
<div class="item-content">
<div class="item-media" style="margin-top: 18px;">
<img class="appImage" src="https://dzmohaipa.com/app/img/freevideo.png" height="85px" style="margin-top: -10px; border-radius:22%;"></a>
</div>
<div class="item-inner">
<div class="item-title-row">
<div class="item-text1" style="   font-size:15px; font-weight: 700;">Free Video</div>
<div class="a"><a style=" font-size: 70%; color: dimgrey; ">9.0Mo</a><a style=" font-size: 83%; color: gray;"> | </a><a style=" font-size: 70%; color: dimgrey;">V3.0.2</a></div>
</div>
<div class="item-install">
<a class="button external button-round button-fill" href="itms-services://?action=download-manifest&amp;url=https://dzmohaipa.com/Snapchat/Free Video.plist" target="_self" onclick="install(Free Video);" style="background:#F0F1F6;color:dodgerblue;font-weight: bold;margin-top: -12px;float:right;">تثبيت</a>
</div>
</div>
</div>
</li>
	        <!-- App -->



	        <!-- App -->
<li>
<div class="item-content">
<div class="item-media" style="margin-top: 18px;">
<img class="appImage" src="https://2.bp.blogspot.com/-vCLeGGvHHwM/Wd7IZVJmLSI/AAAAAAAAA7k/mGLW4Ek31JoRbSMq9EH0NGQDPkdvoXnVgCLcBGAs/s1600/te_le_chargement%2B%25281%2529.png" height="85px" style="margin-top: -10px; border-radius:22%;"></a>
</div>
<div class="item-inner">
<div class="item-title-row">
<div class="item-text1" style="   font-size:15px; font-weight: 700;">GifVid</div>
<div class="a"><a style=" font-size: 70%; color: dimgrey; ">9.5Mo</a><a style=" font-size: 83%; color: gray;"> | </a><a style=" font-size: 70%; color: dimgrey;">V2.9</a></div>
</div>
<div class="item-install">
<a class="button external button-round button-fill" href="itms-services://?action=download-manifest&amp;url=https://dzmohaipa.com/Snapchat/GifVid.plist" target="_self" onclick="install(GifVid);" style="background:#F0F1F6;color:dodgerblue;font-weight: bold;margin-top: -12px;float:right;">تثبيت</a>
</div>
</div>
</div>
</li>
	        <!-- App -->



	        <!-- App -->
<li>
<div class="item-content">
<div class="item-media" style="margin-top: 18px;">
<img class="appImage" src="https://2.bp.blogspot.com/-KsXTs4Sh2uQ/Wd7IzVBYTdI/AAAAAAAAA7w/jpFoDS5hOeUpLzq5CCKexTa6Xhvfn_YqACLcBGAs/s1600/te_le_chargement_1_.png" height="85px" style="margin-top: -10px; border-radius:22%;"></a>
</div>
<div class="item-inner">
<div class="item-title-row">
<div class="item-text1" style="   font-size:15px; font-weight: 700;">ibnQayyim</div>
<div class="a"><a style=" font-size: 70%; color: dimgrey; ">28.5Mo</a><a style=" font-size: 83%; color: gray;"> | </a><a style=" font-size: 70%; color: dimgrey;">V2.1</a></div>
</div>
<div class="item-install">
<a class="button external button-round button-fill" href="itms-services://?action=download-manifest&amp;url=https://dzmohaipa.com/Snapchat/ibnQayyim.plist" target="_self" onclick="install(ibnQayyim);" style="background:#F0F1F6;color:dodgerblue;font-weight: bold;margin-top: -12px;float:right;">تثبيت</a>
</div>
</div>
</div>
</li>
	        <!-- App -->



	        <!-- App -->
<li>
<div class="item-content">
<div class="item-media" style="margin-top: 18px;">
<img class="appImage" src="https://2.bp.blogspot.com/-KsXTs4Sh2uQ/Wd7IzVBYTdI/AAAAAAAAA7w/jpFoDS5hOeUpLzq5CCKexTa6Xhvfn_YqACLcBGAs/s1600/te_le_chargement_1_.png" height="85px" style="margin-top: -10px; border-radius:22%;"></a>
</div>
<div class="item-inner">
<div class="item-title-row">
<div class="item-text1" style="   font-size:15px; font-weight: 700;">iBnTaimia</div>
<div class="a"><a style=" font-size: 70%; color: dimgrey; ">34.7Mo</a><a style=" font-size: 83%; color: gray;"> | </a><a style=" font-size: 70%; color: dimgrey;">V2.3</a></div>
</div>
<div class="item-install">
<a class="button external button-round button-fill" href="itms-services://?action=download-manifest&amp;url=https://dzmohaipa.com/Snapchat/iBnTaimia.plist" target="_self" onclick="install(iBnTaimia);" style="background:#F0F1F6;color:dodgerblue;font-weight: bold;margin-top: -12px;float:right;">تثبيت</a>
</div>
</div>
</div>
</li>
	        <!-- App -->



	        <!-- App -->
<li>
<div class="item-content">
<div class="item-media" style="margin-top: 18px;">
<img class="appImage" src="https://3.bp.blogspot.com/-r11uXO-uwbU/Wd7JyE9zgwI/AAAAAAAAA8A/XxqLfzbwtqkiDYl9TuTR65kY_PTYzZf-gCLcBGAs/s1600/Palringo_Group_Messenger.png" height="85px" style="margin-top: -10px; border-radius:22%;"></a>
</div>
<div class="item-inner">
<div class="item-title-row">
<div class="item-text1" style="   font-size:15px; font-weight: 700;">ParlingoOld</div>
<div class="a"><a style=" font-size: 70%; color: dimgrey; ">10.6Mo</a><a style=" font-size: 83%; color: gray;"> | </a><a style=" font-size: 70%; color: dimgrey;">V6.3.8</a></div>
</div>
<div class="item-install">
<a class="button external button-round button-fill" href="itms-services://?action=download-manifest&amp;url=https://dzmohaipa.com/Snapchat/ParlingoOld.plist" target="_self" onclick="install(ParlingoOld);" style="background:#F0F1F6;color:dodgerblue;font-weight: bold;margin-top: -12px;float:right;">تثبيت</a>
</div>
</div>
</div>
</li>
	        <!-- App -->



	        <!-- App -->
<li>
<div class="item-content">
<div class="item-media" style="margin-top: 18px;">
<img class="appImage" src="https://2.bp.blogspot.com/-KsXTs4Sh2uQ/Wd7IzVBYTdI/AAAAAAAAA7w/jpFoDS5hOeUpLzq5CCKexTa6Xhvfn_YqACLcBGAs/s1600/te_le_chargement_1_.png" height="85px" style="margin-top: -10px; border-radius:22%;"></a>
</div>
<div class="item-inner">
<div class="item-title-row">
<div class="item-text1" style="   font-size:15px; font-weight: 700;">PhotoLayers</div>
<div class="a"><a style=" font-size: 70%; color: dimgrey; ">10.7Mo</a><a style=" font-size: 83%; color: gray;"> | </a><a style=" font-size: 70%; color: dimgrey;">V11.0.0</a></div>
</div>
<div class="item-install">
<a class="button external button-round button-fill" href="itms-services://?action=download-manifest&amp;url=https://dzmohaipa.com/Snapchat/PhotoLayers.plist" target="_self" onclick="install(PhotoLayers);" style="background:#F0F1F6;color:dodgerblue;font-weight: bold;margin-top: -12px;float:right;">تثبيت</a>
</div>
</div>
</div>
</li>
	        <!-- App -->



	        <!-- App -->
<li>
<div class="item-content">
<div class="item-media" style="margin-top: 18px;">
<img class="appImage" src="https://4.bp.blogspot.com/-AzxYwrOCvRM/Wd7KZkWFSvI/AAAAAAAAA8I/3Q6_46_gUrkhTko1SWayTGOmWjr6W71JwCLcBGAs/s1600/te_le_chargement_3_.png" height="85px" style="margin-top: -10px; border-radius:22%;"></a>
</div>
<div class="item-inner">
<div class="item-title-row">
<div class="item-text1" style="   font-size:15px; font-weight: 700;">ProHDRX</div>
<div class="a"><a style=" font-size: 70%; color: dimgrey; ">1.9Mo</a><a style=" font-size: 83%; color: gray;"> | </a><a style=" font-size: 70%; color: dimgrey;">V1.28</a></div>
</div>
<div class="item-install">
<a class="button external button-round button-fill" href="itms-services://?action=download-manifest&amp;url=https://dzmohaipa.com/Snapchat/ProHDRX.plist" target="_self" onclick="install(ProHDRX);" style="background:#F0F1F6;color:dodgerblue;font-weight: bold;margin-top: -12px;float:right;">تثبيت</a>
</div>
</div>
</div>
</li>
	        <!-- App -->



	        <!-- App -->
<li>
<div class="item-content">
<div class="item-media" style="margin-top: 18px;">
<img class="appImage" src="https://2.bp.blogspot.com/-acrcZ1qAwro/Wd7Kt0BTFVI/AAAAAAAAA8Q/lkoAXxacPPI_ZQ5jt0D8iKq3c5ykjxj1gCLcBGAs/s1600/175x175bb_1_.png" height="85px" style="margin-top: -10px; border-radius:22%;"></a>
</div>
<div class="item-inner">
<div class="item-title-row">
<div class="item-text1" style="   font-size:15px; font-weight: 700;">ShipFinder</div>
<div class="a"><a style=" font-size: 70%; color: dimgrey; ">7.8Mo</a><a style=" font-size: 83%; color: gray;"> | </a><a style=" font-size: 70%; color: dimgrey;">V9.0.2</a></div>
</div>
<div class="item-install">
<a class="button external button-round button-fill" href="itms-services://?action=download-manifest&amp;url=https://dzmohaipa.com/Snapchat/ShipFinder.plist" target="_self" onclick="install(ShipFinder);" style="background:#F0F1F6;color:dodgerblue;font-weight: bold;margin-top: -12px;float:right;">تثبيت</a>
</div>
</div>
</div>
</li>
	        <!-- App -->



	        <!-- App -->
<li>
<div class="item-content">
<div class="item-media" style="margin-top: 18px;">
<img class="appImage" src="https://lh3.googleusercontent.com/ZXn4EkSV-yN1DRhd0k8vMWjn2Ldd3YFkfUaj5VfrJ-yuuHpUUXNi5SzELFFD9s2pFw=w300" height="85px" style="margin-top: -10px; border-radius:22%;"></a>
</div>
<div class="item-inner">
<div class="item-title-row">
<div class="item-text1" style="   font-size:15px; font-weight: 700;">RadarbotPro</div>
<div class="a"><a style=" font-size: 70%; color: dimgrey; ">22.1Mo</a><a style=" font-size: 83%; color: gray;"> | </a><a style=" font-size: 70%; color: dimgrey;">V4.1</a></div>
</div>
<div class="item-install">
<a class="button external button-round button-fill" href="itms-services://?action=download-manifest&amp;url=https://dzmohaipa.com/Snapchat/RadarbotPro.plist" target="_self" onclick="install(RadarbotPro);" style="background:#F0F1F6;color:dodgerblue;font-weight: bold;margin-top: -12px;float:right;">تثبيت</a>
</div>
</div>
</div>
</li>
	        <!-- App -->



	        <!-- App -->
<li>
<div class="item-content">
<div class="item-media" style="margin-top: 18px;">
<img class="appImage" src="https://server3.uaepro.me/files/21851/246933.png" height="85px" style="margin-top: -10px; border-radius:22%;"></a>
</div>
<div class="item-inner">
<div class="item-title-row">
<div class="item-text1" style="   font-size:15px; font-weight: 700;">Nestopia</div>
<div class="a"><a style=" font-size: 70%; color: dimgrey; ">16.7Mo</a><a style=" font-size: 83%; color: gray;"> | </a><a style=" font-size: 70%; color: dimgrey;">V1.0</a></div>
</div>
<div class="item-install">
<a class="button external button-round button-fill" href="itms-services://?action=download-manifest&amp;url=https://dzmohaipa.com/Snapchat/Nestopia.plist" target="_self" onclick="install(Nestopia);" style="background:#F0F1F6;color:dodgerblue;font-weight: bold;margin-top: -12px;float:right;">تثبيت</a>
</div>
</div>
</div>
</li>
	        <!-- App -->


            <!-- App -->
<li>
<div class="item-content">
<div class="item-media" style="margin-top: 18px;">
<img class="appImage" src="https://lh3.googleusercontent.com/ZXn4EkSV-yN1DRhd0k8vMWjn2Ldd3YFkfUaj5VfrJ-yuuHpUUXNi5SzELFFD9s2pFw=w300" height="85px" style="margin-top: -10px; border-radius:22%;"></a>
</div>
<div class="item-inner">
<div class="item-title-row">
<div class="item-text1" style="   font-size:15px; font-weight: 700;">RadarbotPro</div>
<div class="a"><a style=" font-size: 70%; color: dimgrey; ">22.1Mo</a><a style=" font-size: 83%; color: gray;"> | </a><a style=" font-size: 70%; color: dimgrey;">V4.1</a></div>
</div>
<div class="item-install">
<a class="button external button-round button-fill" href="itms-services://?action=download-manifest&url=https://cydia-it.ml/raboot.plist" target="_self" onclick="install(RadarbotPro);" style="background:#F0F1F6;color:dodgerblue;font-weight: bold;margin-top: -12px;float:right;">تثبيت</a>
</div>
</div>
</div>
</li>
	        <!-- App -->

							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
