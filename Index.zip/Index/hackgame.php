
<div class="navbar">
  <div class="navbar-inner">
    <div class="left"><a href="#" class="back link"> <i class="icon icon-back"></i><span><h1>رجوع</span></a></div>
  <div class="right">
                        <a class="" href="javascript:window.location.reload(true)"> ♻︎تحديث♻︎ </a>
                     </div>
  </div>

<div class="pages">
  <div data-page="partners" class="page">
     <!-- Search Bar overlay-->
  	<form class="searchbar searchbar-init" data-search-in=".item-inner" data-search-list=".search-here">
								<div class="searchbar-input">
									<input placeholder="recherche..." type="search"><a class="searchbar-clear" href="#"></a>
								</div><a class="searchbar-cancel" href="#">الغاء</a>
							</form>
					<div class="page-content ">
							
		<div class="content-block" style="margin-top:0; margin-bottom:0;">
		<div class="content-block-inner">

		<!-- 	<h3>txt test</h3>
		<p> txt test txt test txt test txt test txt test txt test txt test txt test txt test txt test </p>
	<p>Please report to <a href="https://twitter.com/ipainstall" class="external">@ipainstall</a> if any of these sources or apps are not installing.</p>-->
		</div>
		</div>

							<!-- These are tweaked apps -->
						<div class="list-block search-here searchbar-found" style="margin-top: -1px;">
<ul>

    <!-- Inset content block -->
<br>
	      <!--  <div class="content-block-title">تطبيقات البلس</div>
	    
	    
	    
	        <!-- App -->
<li>
<div class="item-content">
<div class="item-media" style="margin-top: 18px;">
<img class="appImage" src="http://images.tutuapp.com/picture/app_ios/cn/001/97/60/91/1976091.175x175-75.jpg?f=5ccca592461503b131d8f423b792e79c" height="85px" style="margin-top: -10px; border-radius:22%;"></a>
</div>
<div class="item-inner">
<div class="item-title-row">
<div class="item-text1" style="   font-size:15px; font-weight: 700;">ModernCombat 5</div>
<div class="a"><a style=" font-size: 70%; color: dimgrey; ">1.10GB</a><a style=" font-size: 83%; color: gray;"> | </a><a style=" font-size: 70%; color: dimgrey;">v1.5.0</a></div>
</div>
<div class="item-install">
<a class="button external button-round button-fill" href="itms-services://?action=download-manifest&amp;url=https%3A%2F%2Fapi.tweakboxapp.com%2Fdownload%2Fmsru3o5fVZu0q9Rhqbvb3sReiaayY8ejosmp6LZfVmd2Y59qYYyqnY1hVWymZ8psao7fn7Vih5l5mZdpZrnbobpjiGWupMc,%2Ftitle%2FModern%2520Combat%25203Fallen%2520Nation-Infinite%2520Coins" target="_self" onclick="install(ModernCombat 5);" style="background:#F0F1F6;color:dodgerblue;font-weight: bold;margin-top: -12px;float:right;">تثبيت</a>
</div>
</div>
</div>
</li>
	        <!-- App -->



	        <!-- App -->
<li>
<div class="item-content">
<div class="item-media" style="margin-top: 18px;">
<img class="appImage" src="http://images.tutuapp.com/picture/app_ios/us/003/14/17/56/3141756.175x175-75.jpg?f=5ccca592461503b131d8f423b792e79c" height="85px" style="margin-top: -10px; border-radius:22%;"></a>
</div>
<div class="item-inner">
<div class="item-title-row">
<div class="item-text1" style="   font-size:15px; font-weight: 700;">Bike Race Pro</div>
<div class="a"><a style=" font-size: 70%; color: dimgrey; ">90.59MB</a><a style=" font-size: 83%; color: gray;"> | </a><a style=" font-size: 70%; color: dimgrey;">v7.8.1</a></div>
</div>
<div class="item-install">
<a class="button external button-round button-fill" href="itms-services://?action=download-manifest&amp;url=https%3A%2F%2Fapi.tweakboxapp.com%2Fdownload%2Fmsru3o5fVZu0q9Rhqbvb3sReiaayY8ejosmp6LZfVmd4Y5dnYYexnYlmVWymZ8pllY3gn7Vih5l5mZdpZ4-xprhoi2WupMc,%2Ftitle%2FBikeRacePro%2520hack" target="_self" onclick="install(Bike Race Pro);" style="background:#F0F1F6;color:dodgerblue;font-weight: bold;margin-top: -12px;float:right;">تثبيت</a>
</div>
</div>
</div>
</li>
	        <!-- App -->
	        



	        <!-- App -->
<li>
<div class="item-content">
<div class="item-media" style="margin-top: 18px;">
<img class="appImage" src="http://images.tutuapp.com/picture/app_ios/cn/002/13/47/52/56cfc0dfa3de5_fb0f4d9eff2644e2a892493e094c8b97.jpg?f=5ccca592461503b131d8f423b792e79c" height="85px" style="margin-top: -10px; border-radius:22%;"></a>
</div>
<div class="item-inner">
<div class="item-title-row">
<div class="item-text1" style="   font-size:15px; font-weight: 700;">CandyCrush</div>
<div class="a"><a style=" font-size: 70%; color: dimgrey; ">57.97MB</a><a style=" font-size: 83%; color: gray;"> | </a><a style=" font-size: 70%; color: dimgrey;">v1.29.0</a></div>
</div>
<div class="item-install">
<a class="button external button-round button-fill" href="itms-services://?action=download-manifest&amp;url=https%3A%2F%2Fapi.tweakboxapp.com%2Fdownload%2Fmsru3o5fVZu0q9Rhqbvb3sReiaayY8ejosmp6LZfVmd3Y5dmYYqxnYliVWymZ5qUZYuqn7Vih5l5mZdpZ4uup4uUiGWupMc,%2Ftitle%2FCandy%2520Crush%2520Saga-Infinite%2520life" target="_self" onclick="install(CandyCrush);" style="background:#F0F1F6;color:dodgerblue;font-weight: bold;margin-top: -12px;float:right;">تثبيت</a>
</div>
</div>
</div>
</li>
	        <!-- App -->




	        <!-- App -->
<li>
<div class="item-content">
<div class="item-media" style="margin-top: 18px;">
<img class="appImage" src="http://images.tutuapp.com/picture/app_ios/cn/002/78/53/32/2785332.175x175-75.jpg?f=5ccca592461503b131d8f423b792e79c" height="85px" style="margin-top: -10px; border-radius:22%;"></a>
</div>
<div class="item-inner">
<div class="item-title-row">
<div class="item-text1" style="   font-size:15px; font-weight: 700;">8ballpool</div>
<div class="a"><a style=" font-size: 70%; color: dimgrey; ">87.15MB</a><a style=" font-size: 83%; color: gray;"> | </a><a style=" font-size: 70%; color: dimgrey;">v3.10.2</a></div>
</div>
<div class="item-install">
<a class="button external button-round button-fill" href="itms-services://?action=download-manifest&amp;url=https%3A%2F%2Fapi.tweakboxapp.com%2Fdownload%2Fmsru3o5fVZu0q9Rhqbvb3sReiaayY8ejosmp6LZfVmd3Y51rYYutnYdiVWymZ8mZl4jgn7Vih5l5mZdpZoyu0LhpiWWupMc,%2Ftitle%2F8%2520Ball%2520Pool-Endless%2520Guidlines" target="_self" onclick="install(ballpool);" style="background:#F0F1F6;color:dodgerblue;font-weight: bold;margin-top: -12px;float:right;">تثبيت</a>
</div>
</div>
</div>
</li>
	        <!-- App -->


	        <!-- App -->
<li>
<div class="item-content">
<div class="item-media" style="margin-top: 18px;">
<img class="appImage" src="http://images.tutuapp.com/picture/app_ios/cn/001/95/18/71/1951871.175x175-75.jpg?f=5ccca592461503b131d8f423b792e79c" height="85px" style="margin-top: -10px; border-radius:22%;"></a>
</div>
<div class="item-inner">
<div class="item-title-row">
<div class="item-text1" style="   font-size:15px; font-weight: 700;">Score!Hero</div>
<div class="a"><a style=" font-size: 70%; color: dimgrey; ">116.56MB</a><a style=" font-size: 83%; color: gray;"> | </a><a style=" font-size: 70%; color: dimgrey;">v1.40</a></div>
</div>
<div class="item-install">
<a class="button external button-round button-fill" href="itms-services://?action=download-manifest&amp;url=https%3A%2F%2Fapi.tweakboxapp.com%2Fdownload%2Fmsru3o5fVZu0q9Rhqbvb3sReiaayY8ejosmp6LZfVmd2Y59oYYeynYthVWymZ8mZaryvn7Vih5l5mZdpZ4iunoeVX2WupMc,%2Ftitle%2FScore%2521%2520Hero-Hack" target="_self" onclick="install(Score Hero);" style="background:#F0F1F6;color:dodgerblue;font-weight: bold;margin-top: -12px;float:right;">تثبيت</a>
</div>
</div>
</div>
</li>
	        <!-- App -->



	        <!-- App -->
<li>
<div class="item-content">
<div class="item-media" style="margin-top: 18px;">
<img class="appImage" src="http://images.tutuapp.com/picture/app_ios/cn/002/13/46/91/56cfc6dc88151_f5405f0c933048ea9c9bb2e59faee491.jpeg?f=5ccca592461503b131d8f423b792e79c" height="85px" style="margin-top: -10px; border-radius:22%;"></a>
</div>
<div class="item-inner">
<div class="item-title-row">
<div class="item-text1" style="   font-size:15px; font-weight: 700;">Subway Surfers</div>
<div class="a"><a style=" font-size: 70%; color: dimgrey; ">79.35MB</a><a style=" font-size: 83%; color: gray;"> | </a><a style=" font-size: 70%; color: dimgrey;">v1.51.0</a></div>
</div>
<div class="item-install">
<a class="button external button-round button-fill" href="itms-services://?action=download-manifest&amp;url=https%3A%2F%2Fapi.tweakboxapp.com%2Fdownload%2Fmsru3o5fVZu0q9Rhqbvb3sReiaayY8ejosmp6LZfVmd3Y5dmYYqwnY1hVWymZ8pmarrcn7Vih5l5mZdpZLqu04VkWGWupMc,%2Ftitle%2FSubway%2520Surfers-Infinite%2520Coins" target="_self" onclick="install(Subway Surfers);" style="background:#F0F1F6;color:dodgerblue;font-weight: bold;margin-top: -12px;float:right;">تثبيت</a>
</div>
</div>
</div>
</li>
	        <!-- App -->



	        <!-- App -->
<li>
<div class="item-content">
<div class="item-media" style="margin-top: 18px;">
<img class="appImage" src="http://is5.mzstatic.com/image/thumb/Purple117/v4/28/3b/46/283b46c8-94df-6a59-c74a-9fdf96ecc302/source/512x512bb.jpg" height="85px" style="margin-top: -10px; border-radius:22%;"></a>
</div>
<div class="item-inner">
<div class="item-title-row">
<div class="item-text1" style="   font-size:15px; font-weight: 700;">Clash Of Clans Hack</div>
<div class="a"><a style=" font-size: 70%; color: dimgrey; ">87.2MB</a><a style=" font-size: 83%; color: gray;"> | </a><a style=" font-size: 70%; color: dimgrey;">v9.105.11</a></div>
</div>
<div class="item-install">
<a class="button external button-round button-fill" href="itms-services://?action=download-manifest&amp;url=https%3A%2F%2Fapi.tweakboxapp.com%2Fdownload%2Fmsru3sdqVWaqotCiq4Td0sKZlphzpN1im8bbnbWglqqsldOYpYXhz8GVmWaooMemmsXg0cCRlKpzndaU%2Ftitle%2FClash%2520Of%2520Clans%2520Hack" target="_self" onclick="install(Clash Of Clans Hack);" style="background:#F0F1F6;color:dodgerblue;font-weight: bold;margin-top: -12px;float:right;">تثبيت</a>
</div>
</div>
</div>
</li>
	        <!-- App -->



	        <!-- App -->
<li>
<div class="item-content">
<div class="item-media" style="margin-top: 18px;">
<img class="appImage" src="http://images.tutuapp.com/picture/app_ios/cn/002/88/85/63/2888563.175x175-75.jpg?f=311107230ea2fb4a454f12c68fb0bf31" height="85px" style="margin-top: -10px; border-radius:22%;"></a>
</div>
<div class="item-inner">
<div class="item-title-row">
<div class="item-text1" style="   font-size:15px; font-weight: 700;">Super Mario Run-Hack</div>
<div class="a"><a style=" font-size: 70%; color: dimgrey; ">76.23MB</a><a style=" font-size: 83%; color: gray;"> | </a><a style=" font-size: 70%; color: dimgrey;">v2.1.0</a></div>
</div>
<div class="item-install">
<a class="button external button-round button-fill" href="itms-services://?action=download-manifest&amp;url=https%3A%2F%2Fapi.tweakboxapp.com%2Fdownload%2Fmsru3o5fVZu0q9Rhqbvb3sReiaayY8ejosmp6LZfVmd3Y55rYY6vnYpjVWx-mppoYojen7Vih5l5mZdpZrqy0bZniWWupMc,%2Ftitle%2FSuper%2520Mario%2520Run-Hack" target="_self" onclick="install(Super Mario Run-Hack);" style="background:#F0F1F6;color:dodgerblue;font-weight: bold;margin-top: -12px;float:right;">تثبيت</a>
</div>
</div>
</div>
</li>
	        <!-- App -->



	        	        <!-- App -->
<li>
<div class="item-content">
<div class="item-media" style="margin-top: 18px;">
<img class="appImage" src="http://images.tutuapp.com/picture/app_ios/cn/002/54/98/20/2549820.175x175-75.jpg?f=311107230ea2fb4a454f12c68fb0bf31" height="85px" style="margin-top: -10px; border-radius:22%;"></a>
</div>
<div class="item-inner">
<div class="item-title-row">
<div class="item-text1" style="   font-size:15px; font-weight: 700;">Pokemon Go Hack</div>
<div class="a"><a style=" font-size: 70%; color: dimgrey; ">108.88MB</a><a style=" font-size: 83%; color: gray;"> | </a><a style=" font-size: 70%; color: dimgrey;">v0.79.4</a></div>
</div>
<div class="item-install">
<a class="button external button-round button-fill" href="itms-services://?action=download-manifest&amp;url=https%3A%2F%2Fapi.tweakboxapp.com%2Fdownload%2Fmsru3o5fVZu0q9Rhqbvb3sReiaayY8ejosmp6LZfVmd3Y5tnYY-ynYZgVWymZ8lqZIqrn7Vih5l5mZdpZbvbp7hiXGWupMc,%2Ftitle%2FPokemon%2520Go%2520Hack%2520V1.57.5%2520%2520%2520USA%2520Union%2520Square" target="_self" onclick="install(Pokemon Go Hack );" style="background:#F0F1F6;color:dodgerblue;font-weight: bold;margin-top: -12px;float:right;">تثبيت</a>
</div>
</div>
</div>
</li>
	        <!-- App -->



	        <!-- App -->
<li>
<div class="item-content">
<div class="item-media" style="margin-top: 18px;">
<img class="appImage" src="http://images.tutuapp.com/picture/app_ios/cn/002/10/95/59/2109559.175x175-75.jpg?f=311107230ea2fb4a454f12c68fb0bf31" height="85px" style="margin-top: -10px; border-radius:22%;"></a>
</div>
<div class="item-inner">
<div class="item-title-row">
<div class="item-text1" style="   font-size:15px; font-weight: 700;">This War of Mine-hack</div>
<div class="a"><a style=" font-size: 70%; color: dimgrey; ">366.18MB</a><a style=" font-size: 83%; color: gray;"> | </a><a style=" font-size: 70%; color: dimgrey;">v1.2</a></div>
</div>
<div class="item-install">
<a class="button external button-round button-fill" href="itms-services://?action=download-manifest&amp;url=https%3A%2F%2Fapi.tweakboxapp.com%2Fdownload%2Fmsru3o5fVZu0q9Rhqbvb3sReiaayY8ejosmp6LZfVmd3Y5djYY-vnYlpVWymZ8mZZIzen7Vih5l5mZdpZLez04aTWmWupMc,%2Ftitle%2FThis%2520War%2520of%2520Mine-hack" target="_self" onclick="install(This War hack);" style="background:#F0F1F6;color:dodgerblue;font-weight: bold;margin-top: -12px;float:right;">تثبيت</a>
</div>
</div>
</div>
</li>
	        <!-- App -->



	        <!-- App -->
<li>
<div class="item-content">
<div class="item-media" style="margin-top: 18px;">
<img class="appImage" src="http://images.tutuapp.com/picture/app_ios/us/003/14/17/58/3141758.175x175-75.jpg?f=5ccca592461503b131d8f423b792e79c" height="85px" style="margin-top: -10px; border-radius:22%;"></a>
</div>
<div class="item-inner">
<div class="item-title-row">
<div class="item-text1" style="   font-size:15px; font-weight: 700;">Real Racing 3 hack</div>
<div class="a"><a style=" font-size: 70%; color: dimgrey; ">699.70MB</a><a style=" font-size: 83%; color: gray;"> | </a><a style=" font-size: 70%; color: dimgrey;">v5.5.0</a></div>
</div>
<div class="item-install">
<a class="button external button-round button-fill" href="itms-services://?action=download-manifest&amp;url=https%3A%2F%2Fapi.tweakboxapp.com%2Fdownload%2Fmsru3o5fVZu0q9Rhqbvb3sReiaayY8ejosmp6LZfVmd4Y5dnYYexnYloVWymZ8pma7yzn7Vih5l5mZdpZrfeooxlXWWupMc,%2Ftitle%2FReal%2520Racing%25203%2520hack" target="_self" onclick="install(Real Racing hack);" style="background:#F0F1F6;color:dodgerblue;font-weight: bold;margin-top: -12px;float:right;">تثبيت</a>
</div>
</div>
</div>
</li>
	        <!-- App -->



	        <!-- App -->
<li>
<div class="item-content">
<div class="item-media" style="margin-top: 18px;">
<img class="appImage" src="http://images.tutuapp.com/picture/app_ios/us/003/14/17/57/3141757.175x175-75.jpg?f=311107230ea2fb4a454f12c68fb0bf31" height="85px" style="margin-top: -10px; border-radius:22%;"></a>
</div>
<div class="item-inner">
<div class="item-title-row">
<div class="item-text1" style="   font-size:15px; font-weight: 700;">Traffic Rider hack</div>
<div class="a"><a style=" font-size: 70%; color: dimgrey; ">131.64MB</a><a style=" font-size: 83%; color: gray;"> | </a><a style=" font-size: 70%; color: dimgrey;">v1.4</a></div>
</div>
<div class="item-install">
<a class="button external button-round button-fill" href="itms-services://?action=download-manifest&amp;url=https%3A%2F%2Fapi.tweakboxapp.com%2Fdownload%2Fmsru3o5fVZu0q9Rhqbvb3sReiaayY8ejosmp6LZfVmd4Y5dnYYexnYlnVWymZ8pll47bn7Vih5l5mZdpY42toYlliWWupMc,%2Ftitle%2FTraffic%2520Rider%2520hack" target="_self" onclick="install(Traffic Rider hack);" style="background:#F0F1F6;color:dodgerblue;font-weight: bold;margin-top: -12px;float:right;">تثبيت</a>
</div>
</div>
</div>
</li>
	        <!-- App -->



	        <!-- App -->
<li>
<div class="item-content">
<div class="item-media" style="margin-top: 18px;">
<img class="appImage" src="http://images.tutuapp.com/picture/app_ios/cn/002/97/85/10/2978510.175x175-75.png?f=785a290a6a9218f5ea3f3cc27a8504ae" height="85px" style="margin-top: -10px; border-radius:22%;"></a>
</div>
<div class="item-inner">
<div class="item-title-row">
<div class="item-text1" style="   font-size:15px; font-weight: 700;">SlickTV Hack</div>
<div class="a"><a style=" font-size: 70%; color: dimgrey; ">26.99MB</a><a style=" font-size: 83%; color: gray;"> | </a><a style=" font-size: 70%; color: dimgrey;">v1.2</a></div>
</div>
<div class="item-install">
<a class="button external button-round button-fill" href="itms-services://?action=download-manifest&amp;url=https%3A%2F%2Fapi.tweakboxapp.com%2Fdownload%2Fmsru3sdqVWaqotCiq4Td0sKZlphzpN1im8bbncini5iwltWrYcnm17ebmq1zndaU%2Ftitle%2FSlickTv" target="_self" onclick="install(SlickTV Hack);" style="background:#F0F1F6;color:dodgerblue;font-weight: bold;margin-top: -12px;float:right;">تثبيت</a>
</div>
</div>
</div>
</li>
	        <!-- App -->



	        <!-- App -->
<li>
<div class="item-content">
<div class="item-media" style="margin-top: 18px;">
<img class="appImage" src="http://images.tutuapp.com/picture/app_ios/us/003/14/17/62/3141762.175x175-75.jpg?f=311107230ea2fb4a454f12c68fb0bf31" height="85px" style="margin-top: -10px; border-radius:22%;"></a>
</div>
<div class="item-inner">
<div class="item-title-row">
<div class="item-text1" style="   font-size:15px; font-weight: 700;">Gangstar Vegas hack</div>
<div class="a"><a style=" font-size: 70%; color: dimgrey; ">1.53GB</a><a style=" font-size: 83%; color: gray;"> | </a><a style=" font-size: 70%; color: dimgrey;">v3.3.0</a></div>
</div>
<div class="item-install">
<a class="button external button-round button-fill" href="itms-services://?action=download-manifest&amp;url=https%3A%2F%2Fapi.tweakboxapp.com%2Fdownload%2Fmsru3o5fVZu0q9Rhqbvb3sReiaayY8ejosmp6LZfVmd4Y5dnYYexnYpiVWymZ8pmY4bgn7Vih5l5mZdpZYavoYZnWWWupMc,%2Ftitle%2FGangstar%2520Vegas%2520hack" target="_self" onclick="install(Gangstar Vegas hack);" style="background:#F0F1F6;color:dodgerblue;font-weight: bold;margin-top: -12px;float:right;">تثبيت</a>
</div>
</div>
</div>
</li>
	        <!-- App -->



	        <!-- App -->
<li>
<div class="item-content">
<div class="item-media" style="margin-top: 18px;">
<img class="appImage" src="http://images.tutuapp.com/picture/app_ios/us/003/14/17/63/3141763.175x175-75.jpg?f=311107230ea2fb4a454f12c68fb0bf31" height="85px" style="margin-top: -10px; border-radius:22%;"></a>
</div>
<div class="item-inner">
<div class="item-title-row">
<div class="item-text1" style="   font-size:15px; font-weight: 700;">Stickman Legends hack</div>
<div class="a"><a style=" font-size: 70%; color: dimgrey; ">101.20MB</a><a style=" font-size: 83%; color: gray;"> | </a><a style=" font-size: 70%; color: dimgrey;">v1.2.4</a></div>
</div>
<div class="item-install">
<a class="button external button-round button-fill" href="itms-services://?action=download-manifest&amp;url=https%3A%2F%2Fapi.tweakboxapp.com%2Fdownload%2Fmsru3o5fVZu0q9Rhqbvb3sReiaayY8ejosmp6LZfVmd4Y5dnYYexnYpjVWymZ5qZlbuvn7Vih5l5mZdpZIvgn7VpXmWupMc,%2Ftitle%2FStickman%2520Legends%2520hack" target="_self" onclick="install(Stickman Legends hack);" style="background:#F0F1F6;color:dodgerblue;font-weight: bold;margin-top: -12px;float:right;">تثبيت</a>
</div>
</div>
</div>
</li>
	        <!-- App -->



	        <!-- App -->
<li>
<div class="item-content">
<div class="item-media" style="margin-top: 18px;">
<img class="appImage" src="http://images.tutuapp.com/picture/app_ios/cn/002/38/80/43/2388043.175x175-75.jpg?f=311107230ea2fb4a454f12c68fb0bf31" height="85px" style="margin-top: -10px; border-radius:22%;"></a>
</div>
<div class="item-inner">
<div class="item-title-row">
<div class="item-text1" style="   font-size:15px; font-weight: 700;">Craft Royale-Infinite Coins</div>
<div class="a"><a style=" font-size: 70%; color: dimgrey; ">81.46MB</a><a style=" font-size: 83%; color: gray;"> | </a><a style=" font-size: 70%; color: dimgrey;">v1.21</a></div>
</div>
<div class="item-install">
<a class="button external button-round button-fill" href="itms-services://?action=download-manifest&amp;url=https%3A%2F%2Fapi.tweakboxapp.com%2Fdownload%2Fmsru3o5fVZu0q9Rhqbvb3sReiaayY8ejosmp6LZfVmd3Y5lrYY6qnYhjVWymZ5pnmIazn7Vih5l5mZdplYbd0YaVVKC1lQ,,%2Ftitle%2FCraft%2520Royale-Infinite%2520Coins" target="_self" onclick="install(Craft Royale-Infinite Coins);" style="background:#F0F1F6;color:dodgerblue;font-weight: bold;margin-top: -12px;float:right;">تثبيت</a>
</div>
</div>
</div>
</li>
	        <!-- App -->



							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
