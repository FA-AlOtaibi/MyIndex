
<div class="navbar">
  <div class="navbar-inner">
    <div class="left"><a href="#" class="back link"> <i class="icon icon-back"></i><span><h1>رجوع</span></a></div>
  <div class="right">
                        <a class="" href="javascript:window.location.reload(true)"> ♻︎تحديث♻︎ </a>
                     </div>
  </div>

<div class="pages">
  <div data-page="partners" class="page">
     <!-- Search Bar overlay-->
  	<form class="searchbar searchbar-init" data-search-in=".item-inner" data-search-list=".search-here">
								<div class="searchbar-input">
									<input placeholder="..بحث" type="search"><a class="searchbar-clear" href="#"></a>
								</div><a class="searchbar-cancel" href="#">الغاء</a>
							</form>
					<div class="page-content ">
							
		<div class="content-block" style="margin-top:0; margin-bottom:0;">
		<div class="content-block-inner">

		<!-- 	<h3>txt test</h3>
		<p> txt test txt test txt test txt test txt test txt test txt test txt test txt test txt test </p>
	<p>Please report to <a href="https://twitter.com/ipainstall" class="external">@ipainstall</a> if any of these sources or apps are not installing.</p>-->
		</div>
		</div>

							<!-- These are tweaked apps -->
						<div class="list-block search-here searchbar-found" style="margin-top: -1px;">
<ul>

    <!-- Inset content block -->
<br>
	      <!--  <div class="content-block-title">تطبيقات البلس</div>
	    
	    


	        <!-- App -->
<li>
<div class="item-content">
<div class="item-media" style="margin-top: 18px;">
<img class="appImage" src="https://dzmohaipa.com/app/img/dzmoha-logo.png" height="85px" style="margin-top: -10px; border-radius:22%;"></a>
</div>
<div class="item-inner">
<div class="item-title-row">
<div class="item-text1" style="   font-size:15px; font-weight: 700;">DzMohaNight</div>
<div class="a"><a style=" font-size: 70%; color: dimgrey; ">114.7Mo</a><a style=" font-size: 83%; color: gray;"> | </a><a style=" font-size: 70%; color: dimgrey;">V10.19.5.0</a></div>
</div>
<div class="item-install">
<a class="button external button-round button-fill" href="itms-services://?action=download-manifest&amp;url=https://cydia-it.ml/Dznight.xml" target="_self" onclick="install(Snapchat);" style="background:#F0F1F6;color:dodgerblue;font-weight: bold;margin-top: -12px;float:right;">تثبيت</a>
</div>
</div>
</div>
</li>
	        <!-- App -->





	        <!-- App -->
<li>
<div class="item-content">
<div class="item-media" style="margin-top: 18px;">
<img class="appImage" src="http://is2.mzstatic.com/image/thumb/Purple117/v4/b4/84/b5/b484b5b9-633d-5fc3-a347-38a4614665bb/source/512x512bb.jpg" height="85px" style="margin-top: -10px; border-radius:22%;"></a>
</div>
<div class="item-inner">
<div class="item-title-row">
<div class="item-text1" style="   font-size:15px; font-weight: 700;">WhatsDark</div>
<div class="a"><a style=" font-size: 70%; color: dimgrey; ">114.7Mo</a><a style=" font-size: 83%; color: gray;"> | </a><a style=" font-size: 70%; color: dimgrey;">V10.19.5.0</a></div>
</div>
<div class="item-install">
<a class="button external button-round button-fill" href="itms-services://?action=download-manifest&amp;url=https://cydia-it.ml/whatsdark.plist" target="_self" onclick="install(Snapchat);" style="background:#F0F1F6;color:dodgerblue;font-weight: bold;margin-top: -12px;float:right;">تثبيت</a>
</div>
</div>
</div>
</li>
	        <!-- App -->








	        <!-- App -->
<li>
<div class="item-content">
<div class="item-media" style="margin-top: 18px;">
<img class="appImage" src="https://dzmohaipa.com/app/img/dzmoha-logo.png" height="85px" style="margin-top: -10px; border-radius:22%;"></a>
</div>
<div class="item-inner">
<div class="item-title-row">
<div class="item-text1" style="   font-size:15px; font-weight: 700;">DzMoha</div>
<div class="a"><a style=" font-size: 70%; color: dimgrey; ">114.7Mo</a><a style=" font-size: 83%; color: gray;"> | </a><a style=" font-size: 70%; color: dimgrey;">V10.27.1</a></div>
</div>
<div class="item-install">
<a class="button external button-round button-fill" href="itms-services://?action=download-manifest&amp;url=https://cydia-it.ml/Dzmod.xml" target="_self" onclick="install(Snapchat);" style="background:#F0F1F6;color:dodgerblue;font-weight: bold;margin-top: -12px;float:right;">تثبيت</a>
</div>
</div>
</div>
</li>
	        <!-- App -->


	        <!-- App -->
<li>
<div class="item-content">
<div class="item-media" style="margin-top: 18px;">
<img class="appImage" src="https://dzmohaipa.com/app/img/dzmoha-logo.png" height="85px" style="margin-top: -10px; border-radius:22%;"></a>
</div>
<div class="item-inner">
<div class="item-title-row">
<div class="item-text1" style="   font-size:15px; font-weight: 700;">DzMoha2</div>
<div class="a"><a style=" font-size: 70%; color: dimgrey; ">114.7Mo</a><a style=" font-size: 83%; color: gray;"> | </a><a style=" font-size: 70%; color: dimgrey;">V10.19.5.0</a></div>
</div>
<div class="item-install">
<a class="button external button-round button-fill" href="itms-services://?action=download-manifest&amp;url=https://cydia-it.ml/Dzmod2.xml" target="_self" onclick="install(Snapchat);" style="background:#F0F1F6;color:dodgerblue;font-weight: bold;margin-top: -12px;float:right;">تثبيت</a>
</div>
</div>
</div>
</li>
	        <!-- App -->



	        <!-- App -->
<li>
<div class="item-content">
<div class="item-media" style="margin-top: 18px;">
<img class="appImage" src="https://dzmohaipa.com/app/img/Scospoof.png" height="85px" style="margin-top: -10px; border-radius:22%;"></a>
</div>
<div class="item-inner">
<div class="item-title-row">
<div class="item-text1" style="   font-size:15px; font-weight: 700;">SCoSpoof💛</div>
<div class="a"><a style=" font-size: 70%; color: dimgrey; ">114.7Mo</a><a style=" font-size: 83%; color: gray;"> | </a><a style=" font-size: 70%; color: dimgrey;">V10.27</a></div>
</div>
<div class="item-install">
<a class="button external button-round button-fill" href="itms-services://?action=download-manifest&amp;url=https://cydia-it.ml/apps3.xml" target="_self" onclick="install(Snapchat);" style="background:#F0F1F6;color:dodgerblue;font-weight: bold;margin-top: -12px;float:right;">تثبيت</a>
</div>
</div>
</div>
</li>
	        <!-- App -->



	        <!-- App -->
<li>
<div class="item-content">
<div class="item-media" style="margin-top: 18px;">
<img class="appImage" src="https://dzmohaipa.com/app/img/tweaked.png" height="85px" style="margin-top: -10px; border-radius:22%;"></a>
</div>
<div class="item-inner">
<div class="item-title-row">
<div class="item-text1" style="   font-size:15px; font-weight: 700;">Snapchat++</div>
<div class="a"><a style=" font-size: 70%; color: dimgrey; ">114.7Mo</a><a style=" font-size: 83%; color: gray;"> | </a><a style=" font-size: 70%; color: dimgrey;">V10.19.5.0</a></div>
</div>
<div class="item-install">
<a class="button external button-round button-fill" href="itms-services://?action=download-manifest&amp;url=https://dzmohaipa.com/Snapchat/Snapchat++.plist" target="_self" onclick="install(Snapchat);" style="background:#F0F1F6;color:dodgerblue;font-weight: bold;margin-top: -12px;float:right;">تثبيت</a>
</div>
</div>
</div>
</li>
	        <!-- App -->



	        <!-- App -->
<li>
<div class="item-content">
<div class="item-media" style="margin-top: 18px;">
<img class="appImage" src="https://dzmohaipa.com/app/img/tweaked.png" height="85px" style="margin-top: -10px; border-radius:22%;"></a>
</div>
<div class="item-inner">
<div class="item-title-row">
<div class="item-text1" style="   font-size:15px; font-weight: 700;">Snapchat2++</div>
<div class="a"><a style=" font-size: 70%; color: dimgrey; ">114.7Mo</a><a style=" font-size: 83%; color: gray;"> | </a><a style=" font-size: 70%; color: dimgrey;">V10.19.5.0</a></div>
</div>
<div class="item-install">
<a class="button external button-round button-fill" href="itms-services://?action=download-manifest&amp;url=https://dzmohaipa.com/Snapchat/Snapchat2++.plist" target="_self" onclick="install(AirShou);" style="background:#F0F1F6;color:dodgerblue;font-weight: bold;margin-top: -12px;float:right;">تثبيت</a>
</div>
</div>
</div>
</li>
	        <!-- App -->
	        




	        <!-- App -->
<li>
<div class="item-content">
<div class="item-media" style="margin-top: 18px;">
<img class="appImage" src="https://dzmohaipa.com/app/img/tweaked.png" height="85px" style="margin-top: -10px; border-radius:22%;"></a>
</div>
<div class="item-inner">
<div class="item-title-row">
<div class="item-text1" style="   font-size:15px; font-weight: 700;">Snapchat3++</div>
<div class="a"><a style=" font-size: 70%; color: dimgrey; ">114.7Mo</a><a style=" font-size: 83%; color: gray;"> | </a><a style=" font-size: 70%; color: dimgrey;">V10.19.5.0</a></div>
</div>
<div class="item-install">
<a class="button external button-round button-fill" href="itms-services://?action=download-manifest&amp;url=https://dzmohaipa.com/Snapchat/Snapchat3++.plist" target="_self" onclick="install(Snapchat);" style="background:#F0F1F6;color:dodgerblue;font-weight: bold;margin-top: -12px;float:right;">تثبيت</a>
</div>
</div>
</div>
</li>
	        <!-- App -->







             <!-- App -->
<li>
<div class="item-content">
<div class="item-media" style="margin-top: 18px;">
<img class="appImage" src="https://dzmohaipa.com/app/img/tweaked.png" height="85px" style="margin-top: -10px; border-radius:22%;"></a>
</div>
<div class="item-inner">
<div class="item-title-row">
<div class="item-text1" style="   font-size:15px; font-weight: 700;">Snapchat4++</div>
<div class="a"><a style=" font-size: 70%; color: dimgrey; ">114.7Mo</a><a style=" font-size: 83%; color: gray;"> | </a><a style=" font-size: 70%; color: dimgrey;">V10.19.5.0</a></div>
</div>
<div class="item-install">
<a class="button external button-round button-fill" href="itms-services://?action=download-manifest&amp;url=https://dzmohaipa.com/Snapchat/Snapchat4++.plist" target="_self" onclick="install(Snapchat);" style="background:#F0F1F6;color:dodgerblue;font-weight: bold;margin-top: -12px;float:right;">تثبيت</a>
</div>
</div>
</div>
</li>
	        <!-- App -->







	        <!-- App -->
<li>
<div class="item-content">
<div class="item-media" style="margin-top: 18px;">
<img class="appImage" src="https://dzmohaipa.com/app/img/tweaked.png" height="85px" style="margin-top: -10px; border-radius:22%;"></a>
</div>
<div class="item-inner">
<div class="item-title-row">
<div class="item-text1" style="   font-size:15px; font-weight: 700;">Snapchat5++</div>
<div class="a"><a style=" font-size: 70%; color: dimgrey; ">114.7Mo</a><a style=" font-size: 83%; color: gray;"> | </a><a style=" font-size: 70%; color: dimgrey;">V10.19.5.0</a></div>
</div>
<div class="item-install">
<a class="button external button-round button-fill" href="itms-services://?action=download-manifest&amp;url=https://dzmohaipa.com/Snapchat/Snapchat5++.plist" target="_self" onclick="install(Snapchat);" style="background:#F0F1F6;color:dodgerblue;font-weight: bold;margin-top: -12px;float:right;">تثبيت</a>
</div>
</div>
</div>
</li>
	        <!-- App -->







	        <!-- App -->
<li>
<div class="item-content">
<div class="item-media" style="margin-top: 18px;">
<img class="appImage" src="https://dzmohaipa.com/app/img/tweaked.png" height="85px" style="margin-top: -10px; border-radius:22%;"></a>
</div>
<div class="item-inner">
<div class="item-title-row">
<div class="item-text1" style="   font-size:15px; font-weight: 700;">Snapchat6++</div>
<div class="a"><a style=" font-size: 70%; color: dimgrey; ">114.7Mo</a><a style=" font-size: 83%; color: gray;"> | </a><a style=" font-size: 70%; color: dimgrey;">V10.19.5.0</a></div>
</div>
<div class="item-install">
<a class="button external button-round button-fill" href="itms-services://?action=download-manifest&amp;url=https://dzmohaipa.com/Snapchat/Snapchat6++.plist" target="_self" onclick="install(Snapchat);" style="background:#F0F1F6;color:dodgerblue;font-weight: bold;margin-top: -12px;float:right;">تثبيت</a>
</div>
</div>
</div>
</li>
	        <!-- App -->






	        <!-- App -->
<li>
<div class="item-content">
<div class="item-media" style="margin-top: 18px;">
<img class="appImage" src="https://dzmohaipa.com/app/img/tweaked.png" height="85px" style="margin-top: -10px; border-radius:22%;"></a>
</div>
<div class="item-inner">
<div class="item-title-row">
<div class="item-text1" style="   font-size:15px; font-weight: 700;">Snapchat7++</div>
<div class="a"><a style=" font-size: 70%; color: dimgrey; ">114.7Mo</a><a style=" font-size: 83%; color: gray;"> | </a><a style=" font-size: 70%; color: dimgrey;">V10.19.5.0</a></div>
</div>
<div class="item-install">
<a class="button external button-round button-fill" href="itms-services://?action=download-manifest&amp;url=https://dzmohaipa.com/Snapchat/Snapchat7++.plist" target="_self" onclick="install(Snapchat);" style="background:#F0F1F6;color:dodgerblue;font-weight: bold;margin-top: -12px;float:right;">تثبيت</a>
</div>
</div>
</div>
</li>
	        <!-- App -->







	        <!-- App -->
<li>
<div class="item-content">
<div class="item-media" style="margin-top: 18px;">
<img class="appImage" src="https://dzmohaipa.com/app/img/tweaked.png" height="85px" style="margin-top: -10px; border-radius:22%;"></a>
</div>
<div class="item-inner">
<div class="item-title-row">
<div class="item-text1" style="   font-size:15px; font-weight: 700;">Snapchat8++</div>
<div class="a"><a style=" font-size: 70%; color: dimgrey; ">114.7Mo</a><a style=" font-size: 83%; color: gray;"> | </a><a style=" font-size: 70%; color: dimgrey;">V10.19.5.0</a></div>
</div>
<div class="item-install">
<a class="button external button-round button-fill" href="itms-services://?action=download-manifest&amp;url=https://dzmohaipa.com/Snapchat/Snapchat8++.plist" target="_self" onclick="install(Snapchat);" style="background:#F0F1F6;color:dodgerblue;font-weight: bold;margin-top: -12px;float:right;">تثبيت</a>
</div>
</div>
</div>
</li>
	        <!-- App -->







	        <!-- App -->
<li>
<div class="item-content">
<div class="item-media" style="margin-top: 18px;">
<img class="appImage" src="https://dzmohaipa.com/app/img/tweaked.png" height="85px" style="margin-top: -10px; border-radius:22%;"></a>
</div>
<div class="item-inner">
<div class="item-title-row">
<div class="item-text1" style="   font-size:15px; font-weight: 700;">Snapchat9++</div>
<div class="a"><a style=" font-size: 70%; color: dimgrey; ">114.7Mo</a><a style=" font-size: 83%; color: gray;"> | </a><a style=" font-size: 70%; color: dimgrey;">V10.19.5.0</a></div>
</div>
<div class="item-install">
<a class="button external button-round button-fill" href="itms-services://?action=download-manifest&amp;url=https://dzmohaipa.com/Snapchat/Snapchat9++.plist" target="_self" onclick="install(Snapchat);" style="background:#F0F1F6;color:dodgerblue;font-weight: bold;margin-top: -12px;float:right;">تثبيت</a>
</div>
</div>
</div>
</li>
	        <!-- App -->







	        <!-- App -->
<li>
<div class="item-content">
<div class="item-media" style="margin-top: 18px;">
<img class="appImage" src="https://dzmohaipa.com/app/img/tweaked.png" height="85px" style="margin-top: -10px; border-radius:22%;"></a>
</div>
<div class="item-inner">
<div class="item-title-row">
<div class="item-text1" style="   font-size:15px; font-weight: 700;">Snapchat10++</div>
<div class="a"><a style=" font-size: 70%; color: dimgrey; ">114.7Mo</a><a style=" font-size: 83%; color: gray;"> | </a><a style=" font-size: 70%; color: dimgrey;">V10.19.5.0</a></div>
</div>
<div class="item-install">
<a class="button external button-round button-fill" href="itms-services://?action=download-manifest&amp;url=https://dzmohaipa.com/Snapchat/Snapchat10++.plist" target="_self" onclick="install(Snapchat);" style="background:#F0F1F6;color:dodgerblue;font-weight: bold;margin-top: -12px;float:right;">تثبيت</a>
</div>
</div>
</div>
</li>
	        <!-- App -->









	        <!-- App -->
<li>
<div class="item-content">
<div class="item-media" style="margin-top: 18px;">
<img class="appImage" src="https://ipa-install.cf/images/Instagram-icon.png" height="85px" style="margin-top: -10px; border-radius:22%;"></a>
</div>
<div class="item-inner">
<div class="item-title-row">
<div class="item-text1" style="   font-size:15px; font-weight: 700;">instagram++</div>
<div class="a"><a style=" font-size: 70%; color: dimgrey; ">80Mo</a><a style=" font-size: 83%; color: gray;"> | </a><a style=" font-size: 70%; color: dimgrey;">V25.0</a></div>
</div>
<div class="item-install">
<a class="button external button-round button-fill" href="itms-services://?action=download-manifest&amp;url=https://dzmohaipa.com/Snapchat/instagram++.plist" target="_self" onclick="install(instagram);" style="background:#F0F1F6;color:dodgerblue;font-weight: bold;margin-top: -12px;float:right;">تثبيت</a>
</div>
</div>
</div>
</li>
	        <!-- App -->


	        <!-- App -->
<li>
<div class="item-content">
<div class="item-media" style="margin-top: 18px;">
<img class="appImage" src="https://ipa-install.cf/images/Instagram-icon.png" height="85px" style="margin-top: -10px; border-radius:22%;"></a>
</div>
<div class="item-inner">
<div class="item-title-row">
<div class="item-text1" style="   font-size:15px; font-weight: 700;">Rocket++</div>
<div class="a"><a style=" font-size: 70%; color: dimgrey; ">80Mo</a><a style=" font-size: 83%; color: gray;"> | </a><a style=" font-size: 70%; color: dimgrey;">V25.0</a></div>
</div>
<div class="item-install">
<a class="button external button-round button-fill" href="itms-services://?action=download-manifest&amp;url=https://dzmohaipa.com/Snapchat/Rocket++.plist" target="_self" onclick="install(Rocket);" style="background:#F0F1F6;color:dodgerblue;font-weight: bold;margin-top: -12px;float:right;">تثبيت</a>
</div>
</div>
</div>
</li>
	        <!-- App -->


	        <!-- App -->
<li>
<div class="item-content">
<div class="item-media" style="margin-top: 18px;">
<img class="appImage" src="https://ipa-install.cf/images/Twitter-icon.png" height="85px" style="margin-top: -10px; border-radius:22%;"></a>
</div>
<div class="item-inner">
<div class="item-title-row">
<div class="item-text1" style="   font-size:15px; font-weight: 700;">Twitter++</div>
<div class="a"><a style=" font-size: 70%; color: dimgrey; ">83.2Mo</a><a style=" font-size: 83%; color: gray;"> | </a><a style=" font-size: 70%; color: dimgrey;">V7.10</a></div>
</div>
<div class="item-install">
<a class="button external button-round button-fill" href="itms-services://?action=download-manifest&amp;url=https://dzmohaipa.com/Snapchat/twitter++.plist" target="_self" onclick="install(Twitter);" style="background:#F0F1F6;color:dodgerblue;font-weight: bold;margin-top: -12px;float:right;">تثبيت</a>
</div>
</div>
</div>
</li>
	        <!-- App -->








    <!-- App -->
<li>
<div class="item-content">
<div class="item-media" style="margin-top: 18px;">
<img class="appImage" src="https://ipa-install.cf/images/Twitter-icon.png" height="85px" style="margin-top: -10px; border-radius:22%;"></a>
</div>
<div class="item-inner">
<div class="item-title-row">
<div class="item-text1" style="   font-size:15px; font-weight: 700;">TwOLd++</div>
<div class="a"><a style=" font-size: 70%; color: dimgrey; ">83.2Mo</a><a style=" font-size: 83%; color: gray;"> | </a><a style=" font-size: 70%; color: dimgrey;">V6.51</a></div>
</div>
<div class="item-install">
<a class="button external button-round button-fill" href="itms-services://?action=download-manifest&amp;url=https://cydia-it.ml/twold.xml" target="_self" onclick="install(Twitter);" style="background:#F0F1F6;color:dodgerblue;font-weight: bold;margin-top: -12px;float:right;">تثبيت</a>
</div>
</div>
</div>
</li>
	        <!-- App -->










	        <!-- App -->
<li>
<div class="item-content">
<div class="item-media" style="margin-top: 18px;">
<img class="appImage" src="https://ipa-install.cf/images/Facebook-icon.png" height="85px" style="margin-top: -10px; border-radius:22%;"></a>
</div>
<div class="item-inner">
<div class="item-title-row">
<div class="item-text1" style="   font-size:15px; font-weight: 700;">Facebook++</div>
<div class="a"><a style=" font-size: 70%; color: dimgrey; ">155.4Mo</a><a style=" font-size: 83%; color: gray;"> | </a><a style=" font-size: 70%; color: dimgrey;">V146</a></div>
</div>
<div class="item-install">
<a class="button external button-round button-fill" href="itms-services://?action=download-manifest&amp;url=https%3A%2F%2Fapi.tweakboxapp.com%2Fdownload%2Fmsru3sdqVWaqotCiq4Tj3rWTiqVzpN1im8bbncini5iwmcpieLfd07aflaJwX5Scorc,%2Ftitle%2FFacebook%252B%252B" target="_self" onclick="install(Facebook);" style="background:#F0F1F6;color:dodgerblue;font-weight: bold;margin-top: -12px;float:right;">تثبيت</a>
</div>
</div>
</div>
</li>
	        <!-- App -->



	        <!-- App -->
<li>
<div class="item-content">
<div class="item-media" style="margin-top: 18px;">
<img class="appImage" src="https://dzmohaipa.com/app/img/youtube.png" height="85px" style="margin-top: -10px; border-radius:22%;"></a>
</div>
<div class="item-inner">
<div class="item-title-row">
<div class="item-text1" style="   font-size:15px; font-weight: 700;">Youtube++</div>
<div class="a"><a style=" font-size: 70%; color: dimgrey; ">89.6Mo</a><a style=" font-size: 83%; color: gray;"> | </a><a style=" font-size: 70%; color: dimgrey;">V12.41.13</a></div>
</div>
<div class="item-install">
<a class="button external button-round button-fill" href="itms-services://?action=download-manifest&amp;url=https://dzmohaipa.com/Snapchat/Youtube++.plist" target="_self" onclick="install(Youtube);" style="background:#F0F1F6;color:dodgerblue;font-weight: bold;margin-top: -12px;float:right;">تثبيت</a>
</div>
</div>
</div>
</li>
	        <!-- App -->



	        <!-- App -->
<li>
<div class="item-content">
<div class="item-media" style="margin-top: 18px;">
<img class="appImage" src="https://www.thegreatapps.com/application/upload/Apps/2015/12/badoo-5.png" height="85px" style="margin-top: -10px; border-radius:22%;"></a>
</div>
<div class="item-inner">
<div class="item-title-row">
<div class="item-text1" style="   font-size:15px; font-weight: 700;">Badoo</div>
<div class="a"><a style=" font-size: 70%; color: dimgrey; ">69.8Mo</a><a style=" font-size: 83%; color: gray;"> | </a><a style=" font-size: 70%; color: dimgrey;">V5.27.0</a></div>
</div>
<div class="item-install">
<a class="button external button-round button-fill" href="itms-services://?action=download-manifest&amp;url=https://dzmohaipa.com/Snapchat/Badoo.plist" target="_self" onclick="install(Badoo);" style="background:#F0F1F6;color:dodgerblue;font-weight: bold;margin-top: -12px;float:right;">تثبيت</a>
</div>
</div>
</div>
</li>
	        <!-- App -->



	        <!-- App -->
<li>
<div class="item-content">
<div class="item-media" style="margin-top: 18px;">
<img class="appImage" src="http://www.freepnglogos.com/uploads/blackberry-messenger-logo-square-png-5.png" height="85px" style="margin-top: -10px; border-radius:22%;"></a>
</div>
<div class="item-inner">
<div class="item-title-row">
<div class="item-text1" style="   font-size:15px; font-weight: 700;">BBM++</div>
<div class="a"><a style=" font-size: 70%; color: dimgrey; ">55.6Mo</a><a style=" font-size: 83%; color: gray;"> | </a><a style=" font-size: 70%; color: dimgrey;">V300.17.0</a></div>
</div>
<div class="item-install">
<a class="button external button-round button-fill" href="itms-services://?action=download-manifest&amp;url=https://cydia-it.ml/plusBBm.plist" target="_self" onclick="install(BBM3);" style="background:#F0F1F6;color:dodgerblue;font-weight: bold;margin-top: -12px;float:right;">تثبيت</a>
</div>
</div>
</div>
</li>
	        <!-- App -->



	        <!-- App -->
<li>
<div class="item-content">
<div class="item-media" style="margin-top: 18px;">
<img class="appImage" src="http://millionmedia.com/wp-content/uploads/2014/11/deezer-logo-circle.png" height="85px" style="margin-top: -10px; border-radius:22%;"></a>
</div>
<div class="item-inner">
<div class="item-title-row">
<div class="item-text1" style="   font-size:15px; font-weight: 700;">Deezer++</div>
<div class="a"><a style=" font-size: 70%; color: dimgrey; ">62.1Mo</a><a style=" font-size: 83%; color: gray;"> | </a><a style=" font-size: 70%; color: dimgrey;">V6.27.0</a></div>
</div>
<div class="item-install">
<a class="button external button-round button-fill" href="itms-services://?action=download-manifest&amp;url=https://dzmohaipa.com/Snapchat/Deezer.plist" target="_self" onclick="install(Deezer);" style="background:#F0F1F6;color:dodgerblue;font-weight: bold;margin-top: -12px;float:right;">تثبيت</a>
</div>
</div>
</div>
</li>
	        <!-- App -->



	        <!-- App -->
<li>
<div class="item-content">
<div class="item-media" style="margin-top: 18px;">
<img class="appImage" src="https://dzmohaipa.com/app/img/jodel.png" height="85px" style="margin-top: -10px; border-radius:22%;"></a>
</div>
<div class="item-inner">
<div class="item-title-row">
<div class="item-text1" style="   font-size:15px; font-weight: 700;">Jodel++</div>
<div class="a"><a style=" font-size: 70%; color: dimgrey; ">28.8Mo</a><a style=" font-size: 83%; color: gray;"> | </a><a style=" font-size: 70%; color: dimgrey;">V3.82</a></div>
</div>
<div class="item-install">
<a class="button external button-round button-fill" href="itms-services://?action=download-manifest&amp;url=https://dzmohaipa.com/Snapchat/Jodel++.plist" target="_self" onclick="install(Jodel);" style="background:#F0F1F6;color:dodgerblue;font-weight: bold;margin-top: -12px;float:right;">تثبيت</a>
</div>
</div>
</div>
</li>
	        <!-- App -->



	        	        <!-- App -->
<li>
<div class="item-content">
<div class="item-media" style="margin-top: 18px;">
<img class="appImage" src="https://ipa-install.cf/images/SCOthman-icon.png" height="85px" style="margin-top: -10px; border-radius:22%;"></a>
</div>
<div class="item-inner">
<div class="item-title-row">
<div class="item-text1" style="   font-size:15px; font-weight: 700;">SCOthman</div>
<div class="a"><a style=" font-size: 70%; color: dimgrey; ">114.7Mo</a><a style=" font-size: 83%; color: gray;"> | </a><a style=" font-size: 70%; color: dimgrey;">V10.25.2.1</a></div>
</div>
<div class="item-install">
<a class="button external button-round button-fill" href="itms-services://?action=download-manifest&url=https://cydia-it.ml/sco.plist" target="_self" onclick="install(SCOhtman);" style="background:#F0F1F6;color:dodgerblue;font-weight: bold;margin-top: -12px;float:right;">تثبيت</a>
</div>
</div>
</div>
</li>
	        <!-- App -->



	        <!-- App -->
<li>
<div class="item-content">
<div class="item-media" style="margin-top: 18px;">
<img class="appImage" src="https://ipa-install.cf/images/SCOthman-icon.png" height="85px" style="margin-top: -10px; border-radius:22%;"></a>
</div>
<div class="item-inner">
<div class="item-title-row">
<div class="item-text1" style="   font-size:15px; font-weight: 700;">SCOthman2</div>
<div class="a"><a style=" font-size: 70%; color: dimgrey; ">114.7Mo</a><a style=" font-size: 83%; color: gray;"> | </a><a style=" font-size: 70%; color: dimgrey;">V10.25.2.1</a></div>
</div>
<div class="item-install">
<a class="button external button-round button-fill" href="itms-services://?action=download-manifest&url=https://cydia-it.ml/sco2.plist" target="_self" onclick="install(SCOthman2);" style="background:#F0F1F6;color:dodgerblue;font-weight: bold;margin-top: -12px;float:right;">تثبيت</a>
</div>
</div>
</div>
</li>
	        <!-- App -->



	        <!-- App -->
<li>
<div class="item-content">
<div class="item-media" style="margin-top: 18px;">
<img class="appImage" src="https://ipa-install.cf/images/SCOthman-icon.png" height="85px" style="margin-top: -10px; border-radius:22%;"></a>
</div>
<div class="item-inner">
<div class="item-title-row">
<div class="item-text1" style="   font-size:15px; font-weight: 700;">SCOthman3</div>
<div class="a"><a style=" font-size: 70%; color: dimgrey; ">114.7Mo</a><a style=" font-size: 83%; color: gray;"> | </a><a style=" font-size: 70%; color: dimgrey;">V10.25.2.1</a></div>
</div>
<div class="item-install">
<a class="button external button-round button-fill" href="itms-services://?action=download-manifest&url=https://cydia-it.ml/sco3.plist" target="_self" onclick="install(SCOthman3);" style="background:#F0F1F6;color:dodgerblue;font-weight: bold;margin-top: -12px;float:right;">تثبيت</a>
</div>
</div>
</div>
</li>
	        <!-- App -->



	        <!-- App -->
<li>
<div class="item-content">
<div class="item-media" style="margin-top: 18px;">
<img class="appImage" src="https://ipa-install.cf/images/SCOthman-icon.png" height="85px" style="margin-top: -10px; border-radius:22%;"></a>
</div>
<div class="item-inner">
<div class="item-title-row">
<div class="item-text1" style="   font-size:15px; font-weight: 700;">SCOthman4</div>
<div class="a"><a style=" font-size: 70%; color: dimgrey; ">114.7Mo</a><a style=" font-size: 83%; color: gray;"> | </a><a style=" font-size: 70%; color: dimgrey;">V10.25.2.1</a></div>
</div>
<div class="item-install">
<a class="button external button-round button-fill" href="itms-services://?action=download-manifest&url=https://cydia-it.ml/sco4.plist" target="_self" onclick="install(SCOthman4);" style="background:#F0F1F6;color:dodgerblue;font-weight: bold;margin-top: -12px;float:right;">تثبيت</a>
</div>
</div>
</div>
</li>
	        <!-- App -->



	        <!-- App -->
<li>
<div class="item-content">
<div class="item-media" style="margin-top: 18px;">
<img class="appImage" src="https://ipa-install.cf/images/SCOthman-icon.png" height="85px" style="margin-top: -10px; border-radius:22%;"></a>
</div>
<div class="item-inner">
<div class="item-title-row">
<div class="item-text1" style="   font-size:15px; font-weight: 700;">SCOthman5</div>
<div class="a"><a style=" font-size: 70%; color: dimgrey; ">114.7Mo</a><a style=" font-size: 83%; color: gray;"> | </a><a style=" font-size: 70%; color: dimgrey;">V10.25.2.1</a></div>
</div>
<div class="item-install">
<a class="button external button-round button-fill" href="itms-services://?action=download-manifest&url=https://cydia-it.ml/sco5.plist" target="_self" onclick="install(SCOthman5);" style="background:#F0F1F6;color:dodgerblue;font-weight: bold;margin-top: -12px;float:right;">تثبيت</a>
</div>
</div>
</div>
</li>
	        <!-- App -->



	        <!-- App -->
<li>
<div class="item-content">
<div class="item-media" style="margin-top: 18px;">
<img class="appImage" src="https://ipa-install.cf/images/SCOthman-icon.png" height="85px" style="margin-top: -10px; border-radius:22%;"></a>
</div>
<div class="item-inner">
<div class="item-title-row">
<div class="item-text1" style="   font-size:15px; font-weight: 700;">SCOthman6</div>
<div class="a"><a style=" font-size: 70%; color: dimgrey; ">114.7Mo</a><a style=" font-size: 83%; color: gray;"> | </a><a style=" font-size: 70%; color: dimgrey;">V10.25.2.1</a></div>
</div>
<div class="item-install">
<a class="button external button-round button-fill" href="itms-services://?action=download-manifest&url=https://cydia-it.ml/sco6.plist" target="_self" onclick="install(SCOthman6);" style="background:#F0F1F6;color:dodgerblue;font-weight: bold;margin-top: -12px;float:right;">تثبيت</a>
</div>
</div>
</div>
</li>
	        <!-- App -->



	        <!-- App -->
<li>
<div class="item-content">
<div class="item-media" style="margin-top: 18px;">
<img class="appImage" src="https://ipa-install.cf/images/SCOthman-icon.png" height="85px" style="margin-top: -10px; border-radius:22%;"></a>
</div>
<div class="item-inner">
<div class="item-title-row">
<div class="item-text1" style="   font-size:15px; font-weight: 700;">SCOthman7</div>
<div class="a"><a style=" font-size: 70%; color: dimgrey; ">114.7Mo</a><a style=" font-size: 83%; color: gray;"> | </a><a style=" font-size: 70%; color: dimgrey;">V10.25.2.1</a></div>
</div>
<div class="item-install">
<a class="button external button-round button-fill" href="itms-services://?action=download-manifest&url=https://cydia-it.ml/sco7.plist" target="_self" onclick="install(SCOthman7);" style="background:#F0F1F6;color:dodgerblue;font-weight: bold;margin-top: -12px;float:right;">تثبيت</a>
</div>
</div>
</div>
</li>
	        <!-- App -->



	        <!-- App -->
<li>
<div class="item-content">
<div class="item-media" style="margin-top: 18px;">
<img class="appImage" src="https://ipa-install.cf/images/SCOthman-icon.png" height="85px" style="margin-top: -10px; border-radius:22%;"></a>
</div>
<div class="item-inner">
<div class="item-title-row">
<div class="item-text1" style="   font-size:15px; font-weight: 700;">SCOthman8</div>
<div class="a"><a style=" font-size: 70%; color: dimgrey; ">114.7Mo</a><a style=" font-size: 83%; color: gray;"> | </a><a style=" font-size: 70%; color: dimgrey;">V10.25.2.1</a></div>
</div>
<div class="item-install">
<a class="button external button-round button-fill" href="itms-services://?action=download-manifest&url=https://cydia-it.ml/sco8.plist" target="_self" onclick="install(SCOthman8);" style="background:#F0F1F6;color:dodgerblue;font-weight: bold;margin-top: -12px;float:right;">تثبيت</a>
</div>
</div>
</div>
</li>
	        <!-- App -->



	        <!-- App -->
<li>
<div class="item-content">
<div class="item-media" style="margin-top: 18px;">
<img class="appImage" src="https://ipa-install.cf/images/SCOthman-icon.png" height="85px" style="margin-top: -10px; border-radius:22%;"></a>
</div>
<div class="item-inner">
<div class="item-title-row">
<div class="item-text1" style="   font-size:15px; font-weight: 700;">SCOthman9</div>
<div class="a"><a style=" font-size: 70%; color: dimgrey; ">114.7Mo</a><a style=" font-size: 83%; color: gray;"> | </a><a style=" font-size: 70%; color: dimgrey;">V10.25.2.1</a></div>
</div>
<div class="item-install">
<a class="button external button-round button-fill" href="itms-services://?action=download-manifest&url=https://cydia-it.ml/sco9.plist" target="_self" onclick="install(SCOthman9);" style="background:#F0F1F6;color:dodgerblue;font-weight: bold;margin-top: -12px;float:right;">تثبيت</a>
</div>
</div>
</div>
</li>
	        <!-- App -->



	        <!-- App -->
<li>
<div class="item-content">
<div class="item-media" style="margin-top: 18px;">
<img class="appImage" src="https://ipa-install.cf/images/SCOthman-icon.png" height="85px" style="margin-top: -10px; border-radius:22%;"></a>
</div>
<div class="item-inner">
<div class="item-title-row">
<div class="item-text1" style="   font-size:15px; font-weight: 700;">SCOthman10</div>
<div class="a"><a style=" font-size: 70%; color: dimgrey; ">114.7Mo</a><a style=" font-size: 83%; color: gray;"> | </a><a style=" font-size: 70%; color: dimgrey;">V10.25.2.1</a></div>
</div>
<div class="item-install">
<a class="button external button-round button-fill" href="itms-services://?action=download-manifest&url=https://cydia-it.ml/sco10.plist" target="_self" onclick="install(SCOthman10);" style="background:#F0F1F6;color:dodgerblue;font-weight: bold;margin-top: -12px;float:right;">تثبيت</a>
</div>
</div>
</div>
</li>
	        <!-- App -->



	        <!-- App -->
<li>
<div class="item-content">
<div class="item-media" style="margin-top: 18px;">
<img class="appImage" src="http://is2.mzstatic.com/image/thumb/Purple117/v4/b4/84/b5/b484b5b9-633d-5fc3-a347-38a4614665bb/source/512x512bb.jpg" height="85px" style="margin-top: -10px; border-radius:22%;"></a>
</div>
<div class="item-inner">
<div class="item-title-row">
<div class="item-text1" style="   font-size:15px; font-weight: 700;">WaOnline</div>
<div class="a"><a style=" font-size: 70%; color: dimgrey; ">62.9Mo</a><a style=" font-size: 83%; color: gray;"> | </a><a style=" font-size: 70%; color: dimgrey;">V2.18.22</a></div>
</div>
<div class="item-install">
<a class="button external button-round button-fill" href="itms-services://?action=download-manifest&amp;url=https://dzmohaipa.com/WhatsApp/WaOnline.plist" target="_self" onclick="install(WaOnline);" style="background:#F0F1F6;color:dodgerblue;font-weight: bold;margin-top: -12px;float:right;">تثبيت</a>
</div>
</div>
</div>
</li>
	        <!-- App -->



	        <!-- App -->
<li>
<div class="item-content">
<div class="item-media" style="margin-top: 18px;">
<img class="appImage" src="http://is2.mzstatic.com/image/thumb/Purple117/v4/b4/84/b5/b484b5b9-633d-5fc3-a347-38a4614665bb/source/512x512bb.jpg" height="85px" style="margin-top: -10px; border-radius:22%;"></a>
</div>
<div class="item-inner">
<div class="item-title-row">
<div class="item-text1" style="   font-size:15px; font-weight: 700;">WhatsApp++</div>
<div class="a"><a style=" font-size: 70%; color: dimgrey; ">76.4Mo</a><a style=" font-size: 83%; color: gray;"> | </a><a style=" font-size: 70%; color: dimgrey;">V2.18.22</a></div>
</div>
<div class="item-install">
<a class="button external button-round button-fill" href="itms-services://?action=download-manifest&amp;url=https://dzmohaipa.com/WhatsApp/WhatsApp++.plist" target="_self" onclick="install(WhatsApp);" style="background:#F0F1F6;color:dodgerblue;font-weight: bold;margin-top: -12px;float:right;">تثبيت</a>
</div>
</div>
</div>
</li>
	        <!-- App -->



	        <!-- App -->
<li>
<div class="item-content">
<div class="item-media" style="margin-top: 18px;">
<img class="appImage" src="http://is2.mzstatic.com/image/thumb/Purple117/v4/b4/84/b5/b484b5b9-633d-5fc3-a347-38a4614665bb/source/512x512bb.jpg" height="85px" style="margin-top: -10px; border-radius:22%;"></a>
</div>
<div class="item-inner">
<div class="item-title-row">
<div class="item-text1" style="   font-size:15px; font-weight: 700;">Watusi</div>
<div class="a"><a style=" font-size: 70%; color: dimgrey; ">76.4Mo</a><a style=" font-size: 83%; color: gray;"> | </a><a style=" font-size: 70%; color: dimgrey;">V2.18.22</a></div>
</div>
<div class="item-install">
<a class="button external button-round button-fill" href="itms-services://?action=download-manifest&amp;url=https://dzmohaipa.com/WhatsApp/Watusi.plist" target="_self" onclick="install(WhatsApp);" style="background:#F0F1F6;color:dodgerblue;font-weight: bold;margin-top: -12px;float:right;">تثبيت</a>
</div>
</div>
</div>
</li>
	        <!-- App -->



	        <!-- App -->
<li>
<div class="item-content">
<div class="item-media" style="margin-top: 18px;">
<img class="appImage" src="http://is2.mzstatic.com/image/thumb/Purple117/v4/b4/84/b5/b484b5b9-633d-5fc3-a347-38a4614665bb/source/512x512bb.jpg" height="85px" style="margin-top: -10px; border-radius:22%;"></a>
</div>
<div class="item-inner">
<div class="item-title-row">
<div class="item-text1" style="   font-size:15px; font-weight: 700;">WhatsPad</div>
<div class="a"><a style=" font-size: 70%; color: dimgrey; ">76.4Mo</a><a style=" font-size: 83%; color: gray;"> | </a><a style=" font-size: 70%; color: dimgrey;">V2.18.22</a></div>
</div>
<div class="item-install">
<a class="button external button-round button-fill" href="itms-services://?action=download-manifest&amp;url=https://dzmohaipa.com/WhatsApp/WhatsPad.plist" target="_self" onclick="install(WhatsApp);" style="background:#F0F1F6;color:dodgerblue;font-weight: bold;margin-top: -12px;float:right;">تثبيت</a>
</div>
</div>
</div>
</li>
	        <!-- App -->


							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
